rm(list = ls())

library(qualtRics)
library(data.table)

MH_SURVEY <- read_survey("Data/Input/MentalHealthSurvey/Mental_Health_Survey_Feb_20_22.csv")
MH_SURVEY <- as.data.table(MH_SURVEY)

# Not actual survey
MH_SURVEY <- MH_SURVEY[Status!="Survey Preview"]

# Only people who finished
MH_SURVEY <- MH_SURVEY[Finished==TRUE]

# Remove non-full time students
MH_SURVEY = MH_SURVEY[fulltime=="Yes"]

# 583 original, 523 fulltime
MH_SURVEY[, .N]

# Only one fails attention check
table(MH_SURVEY$attention)
MH_SURVEY = MH_SURVEY[attention == "Turquoise"]

# Remove wrong response
MH_SURVEY = MH_SURVEY[is.na(feedback) | 
                        feedback!="I accidentally clicked one of the questions in the section for if I had said 'yes' to being diagnosed with depression - sorry!"]

# remove %2
setnames(MH_SURVEY, "Duration (in seconds)", "durationSeconds")
cutoffSeconds = quantile(MH_SURVEY$durationSeconds, 0.02)
MH_SURVEY = MH_SURVEY[cutoffSeconds < durationSeconds]

# Not using these variables
MH_SURVEY[, c("Status", "Progress", "Finished", "DistributionChannel", "UserLanguage", 
              "survey_intro", "Create New Field or Choose From Dropdown...",
              "FL_11_DO_PHQ-9", "FL_11_DO_GAD-7", "FL_11_DO_ACHA")  := NULL]

# *************************************************************************
#  RENAME ----
# *************************************************************************

# .PHQ-9 ----
# .........................................................................

phqNames = names(MH_SURVEY)[grepl("^phq9_", names(MH_SURVEY))]
for (currentName in phqNames) {
  print(attributes(MH_SURVEY[, get(currentName)]))
}

names(MH_SURVEY)[grepl("^phq9_", names(MH_SURVEY))] = c("phq9_interest", "phq9_depressed", "phq9_sleep", "phq9_tired", "phq9_appetite",
                                                        "phq9_failure", "phq9_concentrating", "phq9_speed", "phq9_selfharm")

# .GAD7 ----
# .........................................................................

gad = names(MH_SURVEY)[grepl("^gad7_", names(MH_SURVEY))]
for (currentName in gad) {
  print(attributes(MH_SURVEY[, get(currentName)]))
}
names(MH_SURVEY)[names(MH_SURVEY) %in% gad] = paste0("gad7_", c("anxious", "control", "worrying", "relaxing", 
                                                                "restless", "annoyed", "afraid"))

# .ACHA ----
# .........................................................................

# How many times in past year
achaNames12Month_times = names(MH_SURVEY)[grepl("^acha_12months_times", names(MH_SURVEY))]
for (currentName in achaNames12Month_times) {
  print(attributes(MH_SURVEY[, get(currentName)]))
}
names(MH_SURVEY)[names(MH_SURVEY) %in% achaNames12Month_times] = paste0("acha_12months_times_", 
                                                                        c("hopeless", "overwhelmed", "exhausted", "sad", 
                                                                          "depressed", "considerSuicide", "attemptSuicide"))
# Have you suffered in last year
achaNames12Month_any = names(MH_SURVEY)[grepl("^acha_12months_any", names(MH_SURVEY))]
for (currentName in achaNames12Month_any) {
  print(attributes(MH_SURVEY[, get(currentName)]))
}
names(MH_SURVEY)[names(MH_SURVEY) %in% achaNames12Month_any] = paste0("acha_12months_any_", 
                                                                      c("allergy", "anorexia", "anxiety", "asthma", "bulimia", "fatigure", "depression", "diabetes", "endometriosi", "herpes",
                                                                        "hpv", "hepatitis", "blood", "cholesterol", "HIV", "stressInjury", "seasonal", "substance", "back", "fracture",
                                                                        "bronchitis", "chlamydia", "ear", "gonorrhea", "mononucleosis", "pelvic", "sinus", "strep", "tuberculosis"))

# Depression services
services = names(MH_SURVEY)[grepl("^acha_services", names(MH_SURVEY))]
for (currentName in services) {
  print(attributes(MH_SURVEY[, get(currentName)]))
}
names(MH_SURVEY)[names(MH_SURVEY) %in% services] = paste0("acha_services_", c("dianosed", "therapy", "medication"))

# race
race = names(MH_SURVEY)[grepl("^race_", names(MH_SURVEY))]
for (currentName in race) {
  print(attributes(MH_SURVEY[, get(currentName)]))
}
names(MH_SURVEY)[names(MH_SURVEY) %in% race] = paste0("race_", c("white", "black", "hispanic", "asian", "native", "other"))

saveRDS(MH_SURVEY, "Data/Intermediate/mhSurvey.rds")