rm(list = ls())


library(dplyr)
library(data.table)
library(ggplot2)
library(kableExtra)
library(glmnet)
library(haven)

MH_SURVEY <- readRDS("Data/Intermediate/mhSurvey.rds")

# Setting seed so LASSO always returns the same result
set.seed(222)

# .phq-9 ----
# .........................................................................

for (phqName in names(MH_SURVEY)[grepl("^phq9_", names(MH_SURVEY))]) {
  MH_SURVEY[, eval(paste0(phqName, "_num")) := fcase(
    get(phqName)=="Not at all", 0,
    get(phqName)=="Several days", 1,
    get(phqName)=="More than half of the days", 2,
    get(phqName)=="Nearly every day", 3)]
}

MH_SURVEY[, phq9Total := phq9_interest_num + phq9_depressed_num + phq9_sleep_num + phq9_tired_num + phq9_appetite_num + 
            phq9_failure_num + phq9_concentrating_num + phq9_speed_num + phq9_selfharm_num]

MH_SURVEY[, phq9Class := fcase(
  20<=phq9Total, "Severe depression",
  15<=phq9Total, "Moderately severe depression",
  10<=phq9Total, "Moderate depression",
  5<=phq9Total, "Mild depression",
  0<=phq9Total, "Minimal depression")]

MH_SURVEY[, phq9Class := factor(phq9Class, levels = c("Minmal depression", "Mild depression", "Moderate depression", 
                                                      "Moderately severe depression", "Severe depression"))]

MH_SURVEY[, phq9Binary := 10<=phq9Total]

# .gad ----
# .........................................................................

for (gadName in names(MH_SURVEY)[grepl("^gad7_", names(MH_SURVEY))]) {
  MH_SURVEY[, eval(paste0(gadName, "_num")) := fcase(
    get(gadName)=="Not at all", 0,
    get(gadName)=="Several days", 1,
    get(gadName)=="More than half of the days", 2,
    get(gadName)=="Nearly every day", 3)]
}

MH_SURVEY[, gad7Total := gad7_afraid_num + gad7_annoyed_num + gad7_anxious_num + gad7_control_num + 
            gad7_relaxing_num + gad7_restless_num + gad7_worrying_num ]

MH_SURVEY[, gad7Class := fcase(
  15<=gad7Total, "Severe anxiety",
  10<=gad7Total, "Moderate anxiety",
  5<=gad7Total, "Mild anxiety",
  0<=gad7Total, "Minimal anxiety")]

MH_SURVEY[, gad7Class := factor(gad7Class, levels = c("Minimal anxiety", "Mild anxiety", "Moderate anxiety", "Severe anxiety"))]
MH_SURVEY[, gad7Binary := 10<=gad7Total]


# .ACHA ----
# .........................................................................

for (achaName in names(MH_SURVEY)[grepl("^acha_12months_times_", names(MH_SURVEY))]) {
  MH_SURVEY[, eval(paste0(gsub("12months_times", "times", achaName), "_num")) := fcase(
    get(achaName)=="Never", 1,
    get(achaName)=="1-2 times", 2,
    get(achaName)=="3-4 times", 3,
    get(achaName)=="5-6 times", 4,
    get(achaName)=="7-8 times", 5,
    get(achaName)=="9-10 times", 6,
    get(achaName)=="11 or more times", 7)]
}

MH_SURVEY[, achaTotal := acha_times_attemptSuicide_num + acha_times_overwhelmed_num + acha_times_hopeless_num + acha_times_exhausted_num + 
            acha_times_considerSuicide_num + acha_times_depressed_num + acha_times_sad_num]

# Services and previous year
achaYesNo = c(names(MH_SURVEY)[grepl("^acha_12months_any", names(MH_SURVEY))],
              names(MH_SURVEY)[grepl("^acha_services_", names(MH_SURVEY))], "acha_depression")
for (achaName in achaYesNo) {
  MH_SURVEY[, eval(paste0(achaName, "_bin")) := fcase(
    get(achaName)=="No", 0,
    get(achaName)=="Yes", 1)]
}

MH_SURVEY[acha_depression_bin==0, acha_services_dianosed_bin := 0]
MH_SURVEY[acha_depression_bin==0, acha_services_therapy_bin := 0]
MH_SURVEY[acha_depression_bin==0, acha_services_medication_bin := 0]

# Create index
numericComp = names(MH_SURVEY)[grepl("acha_times.*num$", names(MH_SURVEY))]
binComp = c("acha_12months_any_anorexia_bin", "acha_12months_any_anxiety_bin", "acha_12months_any_depression_bin", "acha_12months_any_bulimia_bin",
            "acha_12months_any_seasonal_bin")
binServiceComp = c("acha_services_dianosed_bin", "acha_services_therapy_bin", "acha_services_medication_bin")
achaVars = c(numericComp, binComp, binServiceComp)
MH_SURVEY[, eval(paste0(achaVars, "S")) := lapply(.SD, scale), .SDcols = achaVars]
MH_SURVEY[, acha_times_depressed_numS - scale(acha_times_depressed_num)]

for (i in achaVars) {
  MH_SURVEY[is.na(get(i)), stopifnot(.N==0)]
}

MH_SURVEY[, mhNumericMean := rowMeans(.SD), .SDcols = numericComp]
MH_SURVEY[, mhBinMean := rowMeans(.SD), .SDcols = binComp]
MH_SURVEY[, mhBinServiceMean := rowMeans(.SD), .SDcols = binServiceComp]


MH_SURVEY[, indexMean := rowMeans(.SD), .SDcols = paste0(achaVars, "S")]
MH_SURVEY[, mentalHealthIndex := scale(indexMean)]

# .Controls ----
# .........................................................................

# race, don't need name of group in variable, can replace with TRUE/FALSE
for (achaName in names(MH_SURVEY)[grepl("^race*", names(MH_SURVEY))]) {
  MH_SURVEY[, eval(achaName) := !is.na(get(achaName))]
}



# *************************************************************************
#  COMPARE TO OUR SURVEY ----
# *************************************************************************

# Rename variables that exactly the same
MATCH_NAMES = as.data.table(list(
  achaName =  c("eq_index_any_mh_all", "fulltime_student", "white", 
                "q40a", "q40b","q40c", "q40d", 
                "q40e", "q40f", "q40g",
                "q43a2", "q43a3", "q43a5", 
                "q43a7", "q43a17", 
                "q41a", "q41b", "q41c"),
  mhSurveyName = c("mentalHealthIndex", "fulltime", "race_white", 
                   "acha_times_hopeless_num", "acha_times_overwhelmed_num", "acha_times_exhausted_num", "acha_times_sad_num", 
                   "acha_times_depressed_num", "acha_times_considerSuicide_num", "acha_times_attemptSuicide_num",
                   "acha_12months_any_anorexia_bin", "acha_12months_any_anxiety_bin", "acha_12months_any_bulimia_bin", 
                   "acha_12months_any_depression_bin", "acha_12months_any_seasonal_bin", 
                   "acha_services_dianosed_bin", "acha_services_therapy_bin", "acha_services_medication_bin")))

ACHA <- haven::read_dta("Data/Intermediate/ACHA_clean.dta")
ACHA_COMPARE = as.data.table(ACHA)

setnames(ACHA_COMPARE, MATCH_NAMES$achaName, MATCH_NAMES$mhSurveyName)

# .Regression  ----
# .........................................................................

regMH_PHQ = lm(as.formula(paste0("phq9Binary ~ ", paste(achaVars, collapse = " + "))),  data=MH_SURVEY)
regMH_GAD = lm(as.formula(paste0("gad7Binary ~ ", paste(achaVars, collapse = " + "))),  data=MH_SURVEY)

COEF_OLS_PHQ = as.data.table(list(olsValuePhq = regMH_PHQ$coefficients, newName = names(regMH_PHQ$coefficients)))
COEF_OLS_GAD = as.data.table(list(olsValueGad = regMH_GAD$coefficients, newName = names(regMH_GAD$coefficients)))
COEF_OLS = merge(COEF_OLS_PHQ, COEF_OLS_GAD, by="newName")

# Logit
logitMH_PHQ = glm(as.formula(paste0("phq9Binary ~ ", paste(achaVars, collapse = " + "))), data = MH_SURVEY, family = "binomial")
logitMH_GAD = glm(as.formula(paste0("gad7Binary ~ ", paste(achaVars, collapse = " + "))), data = MH_SURVEY, family = "binomial")

COEF_LOGIT_PHQ = as.data.table(list(logitValuePhq = logitMH_PHQ$coefficients, newName = names(logitMH_PHQ$coefficients)))
COEF_LOGIT_GAD = as.data.table(list(logitValueGad = logitMH_GAD$coefficients, newName = names(logitMH_GAD$coefficients)))
COEF_LOGIT = merge(COEF_LOGIT_PHQ, COEF_LOGIT_GAD, by="newName")

# PREPARE Machine learning
predictionVars = c(achaVars, "phq9Binary", "gad7Binary")
predictionData = data.table::copy(MH_SURVEY[, ..predictionVars])
predictionData[, (achaVars) := lapply(.SD, scale), .SDcols = achaVars]
predictionData[, phq9Binary := as.factor(phq9Binary)]
predictionData[, gad7Binary := as.factor(gad7Binary)]

ridgeLassoData = as.matrix(as.data.frame(data.table::copy(predictionData)[, c("phq9Binary", "gad7Binary") :=NULL]))

# LASSO
lassoReg_PHQ = cv.glmnet(ridgeLassoData, as.logical(predictionData$phq9Binary), alpha = 1, family = 'binomial')
lassoReg_GAD = cv.glmnet(ridgeLassoData, as.logical(predictionData$gad7Binary), alpha = 1, family = 'binomial')

coefL_PHQ = as.data.frame(as.matrix(coef(lassoReg_PHQ, c(lassoReg_PHQ$lambda.min))))
COEF_LASSO_PHQ = as.data.table(list(lassoValuePhq = coefL_PHQ$s1, newName = rownames(coefL_PHQ)))

coefL_GAD = as.data.frame(as.matrix(coef(lassoReg_GAD, c(lassoReg_GAD$lambda.min))))
COEF_LASSO_GAD = as.data.table(list(lassoValueGad = coefL_GAD$s1, newName = rownames(coefL_GAD)))

COEF_LASSO = merge(COEF_LASSO_PHQ, COEF_LASSO_GAD, by="newName")

COEF = merge(COEF_OLS, MATCH_NAMES[, list(achaName, newName = mhSurveyName)], by="newName", all.x=TRUE)
COEF = merge(COEF, COEF_LOGIT, by="newName", all.x=TRUE)
COEF = merge(COEF, COEF_LASSO, by="newName", all.x=TRUE)

COEF[, achaNameS := paste0(achaName, "S")]

COEF[!is.na(achaName), fullName := sapply(achaName, function(x) attributes(ACHA[[x]])$label)]
COEF[newName=="(Intercept)", fullName := "Intercept"]

cols = c("olsValuePhq", "olsValueGad", "logitValuePhq", "logitValueGad")
COEF[, eval(paste0(cols, "Coef")) := lapply(.SD, function(x) 
  paste0(round(x, 5), ifelse(newName!="(Intercept)", paste0("*", achaName), ""))), .SDcols = cols]

colsLaso = c("lassoValuePhq", "lassoValueGad")
COEF[, eval(paste0(colsLaso, "Coef")) := lapply(.SD, function(x) 
  paste0(round(x, 5), ifelse(newName!="(Intercept)", paste0("*", achaNameS), ""))), .SDcols = colsLaso]

COEF[, fullNameF := factor(fullName, 
                           levels = c("Intercept",
                                      "Last year felt hopeless", "Last year felt overwhelmed", "Last year felt exhausted", "Last year felt very sad",
                                      "Last year severely depressed", "Last year seriously considered suicide", "Last year attempted suicide",
                                      "Last year depression",
                                      "Last year anorexia", "Last year anxiety disorder", "Last year bulimia", "Last year seasonal affect disorder",
                                      "Last year depression diagnosis", "Therapy depression", "Current medication depression"))]
COEF = COEF[order(fullNameF)]

COEF_TABLE <- COEF[, list(fullNameF, olsValuePhq, logitValuePhq, lassoValuePhq, olsValueGad, logitValueGad, lassoValueGad)]
valueCols = grep("Value", names(COEF_TABLE), value=TRUE)
COEF_TABLE[, eval(valueCols) := round(.SD, 3), .SDcols = valueCols]

kable(COEF_TABLE, col.names = c("Variable", rep(c("OLS", "Logit", "LASSO"), 2)), format = "latex", booktabs=TRUE) %>% 
  add_header_above(c(" " = 1, "10$\\\\leq$PHQ-9 Coefficients" = 3, "10$\\\\leq$GAD-7 Coefficients" = 3), escape = FALSE) %>% 
  pack_rows("Depression Symptoms", 2, 9) %>%
  pack_rows("Other Symptoms", 10, 13) %>%
  pack_rows("Depression Services", 14, 16) %>%
  cat(file = "Exhibits/Table A29.tex")
